package checkups;

import utils.Constants;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by Alexey on 04.07.2015.
 */
public class NumerGenerateTeset {

    public static void main(String[] args) {
//        System.out.println(getFreeNumberSet(4));
//        for( int i =1; i<6;i++){
//            System.out.println(getFreeNumber());
//        }
    }
}
