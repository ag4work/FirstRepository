package checkups;

/**
 * Created by Alexey on 06.07.2015.
 */
public class streq {
    public static void main(String[] args) {
        String s = null;

        if (s !=null && s.equals("s")){
            System.out.println("eq");
        }
        else {
            System.out.println("no eq");
        }

    }
}
