package exceptions;

/**
 * Created by Alexey on 12.07.2015.
 */
public class BlockedByStaffException extends Exception {
}
