package exceptions;

/**
 * Created by Alexey on 11.07.2015.
 */
public class OptionInconsistencyImpossibleException extends Exception {
}
