package DAO;

import entity.User;

/**
 * Created by Alexey on 25.06.2015.
 */
public interface UserDAO extends DAOOperations<User> {

}
