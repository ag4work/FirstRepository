package DAO;


import entity.Tariff;

/**
 * Created by Alexey on 01.07.2015.
 */

public interface TariffDAO extends DAOOperations<Tariff>  {

}

