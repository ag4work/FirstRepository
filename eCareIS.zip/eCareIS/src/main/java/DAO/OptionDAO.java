package DAO;

import entity.Option;

/**
 * Created by Alexey on 01.07.2015.
 */
public interface OptionDAO extends DAOOperations<Option> {

}
